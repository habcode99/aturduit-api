package com.demo.aturduitapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AturduitApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AturduitApiApplication.class, args);
	}

}
