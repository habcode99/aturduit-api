package com.demo.aturduitapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AturduitApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
